// dev.js - dont commit this
module.exports = {
  googleClientID:
    "1036056115223-ge77odtlqme0i34qaf64tj52q9k9crjo.apps.googleusercontent.com",
  googleClientSecret: "URcqUy75n9kGqfXvY4kuOM7p",
  mongoURI:
    "mongodb+srv://pennez_max:pennez@cluster0-sixtj.mongodb.net/pennezApp?retryWrites=true",
  cookieKey: "bkjabduadoiaoqkkqkjnnmza",
  sendGridKey:
    "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",
  redirectDomain: "http://localhost:3000",
  awsKeyId: "AKIAJA3M26UTGRNQJZ6A",
  awsSecretId: "g/c9hT+jx07gAyo53ZCjNGQgpgDwaQiNgJ82xfKh"
};
