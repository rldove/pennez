import React from "react";
import AccountProfile from "./accounts/AccountProfile";

const Profile = () => {
  return (
    <div>
      <AccountProfile />
    </div>
  );
};

export default Profile;
