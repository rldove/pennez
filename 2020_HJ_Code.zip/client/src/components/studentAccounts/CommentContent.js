import React, { Component } from "react";

class CommentContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      status: ""
    };
  }

  render() {
    return <div>Hello</div>;
  }
}
export default CommentContent;
