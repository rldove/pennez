export default [
  { label: "Lexile SGRPL", name: "lexileSGRPL" },
  { label: "Reading Level", name: "readingGradeLevel" },
  { label: "Fiction", name: "fiction" },
  { label: "Source Name", name: "sourceName" },
  { label: "Source Content", name: "sourceContent" },
  { label: "Word Counts", name: "wordCounts" }
];
