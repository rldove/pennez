export default [
  { label: "Username", name: "username" },
  { label: "First Name", name: "firstName" },
  { label: "Last Name", name: "familyName" },
  { label: "Email Address", name: "email" },
  { label: "Phone Number", name: "phoneNum" },
  { label: "Password", name: "password" },
  { label: "Account Type", name: "accountType" },
  { label: "Street", name: "addressStreet" },
  { label: "City", name: "addressCity" },
  { label: "State", name: "addressState" },
  { label: "Zip Code", name: "addressZipcode" },
  { label: "School Type", name: "schoolType" }
];
