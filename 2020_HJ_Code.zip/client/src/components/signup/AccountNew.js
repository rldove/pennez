import React, { Component } from "react";
import AccountTypes from "./AccountTypes";

class AccountNew extends Component {
  render() {
    return (
      <div>
        <AccountTypes />
      </div>
    );
  }
}

export default AccountNew;
