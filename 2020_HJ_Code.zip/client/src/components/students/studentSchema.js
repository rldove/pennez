export default [
  { label: "First Name", name: "firstName" },
  { label: "Last Name", name: "lastName" },
  { label: "School District Name", name: "schoolDistrictName" },
  { label: "State", name: "state" },
  { label: "Zip Code", name: "zipCode" },
  { label: "Current Grade Level", name: "currentGradeLevel" },
  {
    label: "First Name and Last Name of Teacher",
    name: "firstName_lastName_teacher"
  },
  { label: "Username", name: "userName" },
  { label: "Password", name: "password" },
  { label: "Lexile Reading Level", name: "lexileReadingLevel" },
  { label: "Reading Grade Level", name: "readingGradeLevel" }
];
