export default [
  { label: "username", name: "username" },
  { label: "Password", name: "password" }
];
