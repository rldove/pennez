export const FETCH_USER = "fetch_user";
export const FETCH_SURVEYS = "fetch_surveys";
export const FETCH_STUDENTS = "fetch_students";
export const FETCH_ACCOUNT = "fetch_account";
export const FETCH_VOICE = "fetch_voice";
export const FETCH_STUDENT_SOURCE = "fetch_student_source";
export const FETCH_LOGIN_ERROR = "fetch_login_error";
